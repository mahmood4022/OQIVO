package com.oqivo.game;

import android.app.Activity;
import android.os.Bundle;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdListener;

import java.util.Arrays;
import java.util.List;

public class MainActivity extends Activity {
    private WebView webView;
    private AdView banner;
    private InterstitialAd interstitial;
    private BillingClient billingClient;
    private ProductDetails removeAdsProduct;
    private boolean adsRemoved = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MobileAds.initialize(this, status -> loadBanner());

        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.loadUrl("file:///android_asset/index.html");

        setupBilling();
    }

    private void loadBanner() {
        if (adsRemoved || banner != null) return;
        banner = new AdView(this);
        banner.setAdSize(AdSize.BANNER);
        banner.setAdUnitId("ca-app-pub-3940256099942544/6300978111");
        FrameLayout root = (FrameLayout) webView.getParent();
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, -2);
        lp.gravity = android.view.Gravity.BOTTOM;
        root.addView(banner, lp);
        banner.setAdListener(new AdListener() {});
        banner.loadAd(new AdRequest.Builder().build());
    }

    private void loadInterstitial() {
        if (adsRemoved) return;
        InterstitialAd.load(this, "ca-app-pub-3940256099942544/1033173712",
                new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                    @Override public void onAdLoaded(InterstitialAd ad) { interstitial = ad; }
                    @Override public void onAdFailedToLoad(LoadAdError error) { interstitial = null; }
                });
    }

    private void setupBilling() {
        billingClient = BillingClient.newBuilder(this)
                .setListener((result, purchases) -> {
                    if (purchases != null) handlePurchases(purchases);
                })
                .enablePendingPurchases()
                .build();
        billingClient.startConnection(new BillingClientStateListener() {
            @Override public void onBillingSetupFinished(BillingResult result) {
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    queryRemoveAds();
                    queryPurchases();
                }
            }
            @Override public void onBillingServiceDisconnected() { }
        });
    }

    private void queryRemoveAds() {
        QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder()
                .setProductList(Arrays.asList(
                        QueryProductDetailsParams.Product.newBuilder()
                                .setProductId("remove_ads")
                                .setProductType(BillingClient.ProductType.INAPP)
                                .build()))
                .build();
        billingClient.queryProductDetailsAsync(params, (result, productDetailsList) -> {
            if (result.getResponseCode() == BillingClient.BillingResponseCode.OK && productDetailsList != null && !productDetailsList.isEmpty()) {
                removeAdsProduct = productDetailsList.get(0);
            }
        });
    }

    private void queryPurchases() {
        billingClient.queryPurchasesAsync(
                com.android.billingclient.api.QueryPurchasesParams.newBuilder()
                        .setProductType(BillingClient.ProductType.INAPP).build(),
                (result, purchases) -> {
                    if (purchases != null) handlePurchases(purchases);
                });
    }

    private void handlePurchases(List<Purchase> purchases) {
        for (Purchase p : purchases) {
            if (p.getProducts().contains("remove_ads") && p.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
                adsRemoved = true;
                runJs("window.setAdsRemoved(true)");
                if (p.isAcknowledged()) continue;
                billingClient.acknowledgePurchase(
                        com.android.billingclient.api.AcknowledgePurchaseParams.newBuilder()
                                .setPurchaseToken(p.getPurchaseToken()).build(), r -> {});
            }
        }
        if (adsRemoved && banner != null) { banner.destroy(); banner = null; }
    }

    private void runJs(String js) { runOnUiThread(() -> webView.evaluateJavascript(js, null)); }

    public class AndroidBridge {
        @JavascriptInterface public void buyRemoveAds() {
            runOnUiThread(() -> {
                if (removeAdsProduct == null) {
                    runJs("window.billingUnavailable()" );
                    return;
                }
                BillingFlowParams.ProductDetailsParams pd = BillingFlowParams.ProductDetailsParams.newBuilder()
                        .setProductDetails(removeAdsProduct).build();
                BillingFlowParams flow = BillingFlowParams.newBuilder()
                        .setProductDetailsParamsList(Arrays.asList(pd)).build();
                billingClient.launchBillingFlow(MainActivity.this, flow);
            });
        }
        @JavascriptInterface public void showInterstitial() {
            runOnUiThread(() -> {
                if (interstitial != null && !adsRemoved) {
                    interstitial.show(MainActivity.this);
                    interstitial = null;
                    loadInterstitial();
                } else loadInterstitial();
            });
        }
        @JavascriptInterface public void restorePurchases() { queryPurchases(); }
        @JavascriptInterface public boolean adsAreRemoved() { return adsRemoved; }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
